---
layout: post
title:  "NUnit Xamarin Runners 3.6.1 Released"
date:   2017-03-16 12:00:00 -0000
categories: news update nunit
---
An update to the NUnit Xamarin runners has been released. This update includes a number of new features including XML output, results over TCP, and improvements for integration with CI systems.

Install the runners from [NuGet](https://www.nuget.org/packages/nunit.xamarin/) or by searching for the package nunit.xamarin.

For more information, see the [GitHub](https://github.com/nunit/nunit.xamarin) page.