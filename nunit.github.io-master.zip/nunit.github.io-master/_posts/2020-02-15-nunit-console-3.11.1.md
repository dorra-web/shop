---
layout: post
title:  "NUnit Console and Engine 3.11.1 Released"
date:   2020-02-15 12:00:00 -0000
categories: news update nunit
---

Version 3.11.1 of the NUnit Console and Engine has now been released. This hotfix fixes a problem with NUnit Project file settings being ignored.

You may download NUnit Console 3.11.1 from [GitHub](https://github.com/nunit/nunit-console/releases). See the [release notes](https://github.com/nunit/docs/wiki/Console-Release-Notes) for more information.
