---
layout: post
title:  "NUnit2 TestAdapter 2.2 Released for VS2019 support"
date:   2019-06-05 12:00:00 -0000
categories: news update nunit
---

This release is for supporting VS 2019 and VS 2017 SDK projects.  See further details in [this post](https://hermit.no/new-version-of-the-nunit-2-adapter-supporting-visual-studio-2019/)

[Download NuGet adapter](https://www.nuget.org/packages/NUnitTestAdapter/2.2.0)
[Download VSIX adapter](https://marketplace.visualstudio.com/items?itemName=NUnitDevelopers.NUnitTestAdapter)
[Release Notes](https://github.com/nunit/docs/wiki/AdapterV2-Release-Notes)



