---
layout: post
title:  "NUnit Visual Studio Project Loader 3.7 Released"
date:   2017-11-18 12:00:00 -0000
categories: news update nunit
---
We have released an update to the Visual Studio Project Loader extension.

This release adds support for new .csproj file format, and resolves an issue with missing optional project elements.

Download from [GitHub](https://github.com/nunit/vs-project-loader/releases), [NuGet](https://www.nuget.org/packages/NUnit.Extension.VSProjectLoader/) or [Chocolatey](https://chocolatey.org/packages/nunit-extension-vs-project-loader).