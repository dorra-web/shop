NUnit Test Generator extension for Visual Studio 2017 version 2.1 is released.

Supports new structure for Visual Studio 2017 Update 9 and forward.
(Note: If not disabled in VS, this extension is automatically updated once installed)

See [the release notes](https://github.com/nunit/docs/wiki/TestGenerator-Release-Notes)

[Download VSIX](https://marketplace.visualstudio.com/items?itemName=NUnitDevelopers.TestGeneratorNUnitextension-18371)