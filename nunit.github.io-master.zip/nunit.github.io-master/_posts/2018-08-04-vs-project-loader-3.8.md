---
layout: post
title:  "NUnit Visual Studio Project Loader 3.8 Released"
date:   2018-08-04 12:00:00 -0000
categories: news update nunit
---
We have released an update to the Visual Studio Project Loader extension.

This release contains miscellaneous bug fixes - see the changelog for more details.

Download from [GitHub](https://github.com/nunit/vs-project-loader/releases), [NuGet](https://www.nuget.org/packages/NUnit.Extension.VSProjectLoader/) or [Chocolatey](https://chocolatey.org/packages/nunit-extension-vs-project-loader).