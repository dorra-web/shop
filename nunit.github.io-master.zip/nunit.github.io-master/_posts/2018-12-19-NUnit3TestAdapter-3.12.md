NUnit3TestAdapter version 3.12.0 is released.

This release focuses on two enhancements: generating NUnit3 Test Results XML and updating the NUnit engine which avoids clashes with user test project dependencies.
See [the release notes](https://github.com/nunit/docs/wiki/Adapter-Release-Notes) for details on what has changed in 3.12.  
[Download NuGet package](https://www.nuget.org/packages/NUnit3TestAdapter/3.12.0)
[Download VSIX](https://marketplace.visualstudio.com/items?itemName=NUnitDevelopers.NUnit3TestAdapter)
