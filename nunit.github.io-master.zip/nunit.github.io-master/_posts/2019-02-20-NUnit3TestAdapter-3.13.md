NUnit3TestAdapter version 3.13.0 is released.

This release focuses on enhancements: improving and fixing the generation of NUnit3 Test Results XML and removing internal properties.  It also ensures that the VSIX version works with VS2019. 
See [the release notes](https://github.com/nunit/docs/wiki/Adapter-Release-Notes) for details on what has changed in 3.13.  
[Download NuGet package](https://www.nuget.org/packages/NUnit3TestAdapter/3.13.0)
[Download VSIX](https://marketplace.visualstudio.com/items?itemName=NUnitDevelopers.NUnit3TestAdapter)