---
layout: post
title:  "NUnit Console 3.7 Released"
date:   2017-06-13 12:00:00 -0000
categories: news update nunit
---
This release of the NUnit console runner and engine creates a .NET Standard version of the engine for use in the Visual Studio Adapter. It also fixes several issues that caused the runner to exit with a SocketException.

You may download NUnit Console 3.7 from [Github](https://github.com/nunit/nunit-console/releases). See the [release notes](https://github.com/nunit/docs/wiki/Release-Notes) for more information.