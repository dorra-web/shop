NUnit3TestAdapter, version 3.8 is released.

Major feature is support for .NET Core /.NET Standard. 

See [the release notes](https://github.com/nunit/docs/wiki/Adapter-Release-Notes) for other fixes.

[Download nuget package](https://www.nuget.org/packages/NUnit3TestAdapter/3.8.0)

[Download VSIX](https://marketplace.visualstudio.com/items?itemName=NUnitDevelopers.NUnit3TestAdapter)
