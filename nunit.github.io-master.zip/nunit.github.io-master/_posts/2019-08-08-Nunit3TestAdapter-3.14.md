NUnit3TestAdapter version 3.14.0 is released.

This release has a set of features and enhancements, and a couple of bug fixes.
  
See [the release notes](https://github.com/nunit/docs/wiki/Adapter-Release-Notes) for details on what has changed in 3.14.  
[Download NuGet package](https://www.nuget.org/packages/NUnit3TestAdapter/3.14.0)
[Download VSIX](https://marketplace.visualstudio.com/items?itemName=NUnitDevelopers.NUnit3TestAdapter)