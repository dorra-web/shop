---
layout: post
title:  "NUnit Visual Studio Templates 1.3 Released"
date:   2017-04-04 12:00:00 -0000
categories: news update nunit
---
We have released an update to the NUnit Visual Studio Templates, to integrate with Visual Studio 2017.

The release also includes various bug fixes, and upgrades the templates to the latest versions of the framework and nunit.xamarin.

Download from the [Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=NUnitDevelopers.NUnitTemplatesforVisualStudio).