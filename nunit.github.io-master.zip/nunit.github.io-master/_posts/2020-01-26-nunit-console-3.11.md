---
layout: post
title:  "NUnit Console and Engine 3.11 Released"
date:   2020-01-26 12:00:00 -0000
categories: news update nunit
---

Version 3.11 of the NUnit Console and Engine has now been released. This release fixes a range of minor bugs and includes a significant amount of internal restructuring work. In future, this will enable improved .NET Standard support in the engine and a .NET Core build of the console.

You may download NUnit Console 3.11 from [GitHub](https://github.com/nunit/nunit-console/releases). See the [release notes](https://github.com/nunit/docs/wiki/Console-Release-Notes) for more information.
