---
layout: post
title:  "NUnit Console and Engine 3.13.2 Released"
date:   2022-01-05 12:00:00 -0000
categories: news update nunit
---

This is another build-only milestone. The previous release, 3.13.1, required some intervention in order to complete correctly. The build fixes in this one are intended to allow publishing and release to run to completion.

There are no user-facing fixes or improvements in this release.

You can download the NUnit Console from [GitHub](https://github.com/nunit/nunit-console/releases), [NuGet](https://www.nuget.org/) or [Chocolatey](https://www.chocolatey.org/profiles/nunit.org). See the [release notes](https://docs.nunit.org/articles/nunit/release-notes/console-and-engine.html) for more information.
