NUnit3TestAdapter version 3.11.2 is released.

See [the release notes](https://github.com/nunit/docs/wiki/Adapter-Release-Notes) for what has changed.  Also see section for release 3.11 which contains the bugs and features. 

[Download NuGet package](https://www.nuget.org/packages/NUnit3TestAdapter/3.11.2)

[Download VSIX](https://marketplace.visualstudio.com/items?itemName=NUnitDevelopers.NUnit3TestAdapter)