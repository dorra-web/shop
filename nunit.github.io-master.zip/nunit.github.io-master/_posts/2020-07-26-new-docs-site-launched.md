---
layout: post
title:  "NUnit Launches docs.nunit.org, Welcomes Sean Killeen as Docs Project Lead"
date:   2020-07-26 12:00:00 -0000
categories: news update nunit docs
---

NUnit's documentation has moved from its former GitHub wiki to a new site at <https://docs.nunit.org>. The site is now built from the content at the [nunit/docs GitHub repository](https://github.com/nunit/docs).

[Sean Killeen](https://SeanKilleen.com) has joined the NUnit team as the new lead of the docs project. We welcome Sean to the project, and are excited to see everyone's great contributions to the docs going forward!
